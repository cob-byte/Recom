package com.example.recom;

public class wList {
    int imageID;
    String heading, description;

    public wList(int imageID, String heading, String description) {
        this.imageID = imageID;
        this.heading = heading;
        this.description = description;
    }
}
